package com.gabo.quiz10.comon.handleResponse

import retrofit2.Response

interface HandleResponse {
    suspend fun <M : Any> handleResponse(
        request: suspend () -> Response<M>,
        defaultMessage: String
    ): Resource<M> {
        return try {
            val result = request.invoke()
            val body = result.body()
            if (result.isSuccessful && body != null) {
                return Resource.Success(body)
            } else {
                Resource.Error(result.message() ?: defaultMessage)
            }
        } catch (e: Throwable) {
            Resource.Error("Something went wrong!")
        }
    }
}