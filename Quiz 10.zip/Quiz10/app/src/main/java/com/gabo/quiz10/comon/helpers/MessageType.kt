package com.gabo.quiz10.comon.helpers

enum class MessageType {
    text, voice, attachment
}