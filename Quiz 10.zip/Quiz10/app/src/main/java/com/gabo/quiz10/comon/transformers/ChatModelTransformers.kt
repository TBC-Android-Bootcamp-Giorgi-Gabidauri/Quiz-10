package com.gabo.quiz10.comon.transformers

import com.gabo.quiz10.data.dto.ChatDto
import com.gabo.quiz10.domain.model.ChatModel

fun ChatDto.toModel() = ChatModel(
    id,
    email,
    firstName,
    lastName,
    avatar,
    messageType,
    lastMessage,
    unreadMessage,
    isTyping,
    updatedDate
)