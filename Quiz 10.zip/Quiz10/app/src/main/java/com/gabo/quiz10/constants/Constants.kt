package com.gabo.quiz10.constants


const val BASE_URL = "https://run.mocky.io"
const val CHAT_END_POINT =
    "/v3/80d25aee-d9a6-4e9c-b1d1-80d2a7c979bf?fbclid=IwAR3-w0TMe0oKjkwtuZIt4NklTGGapR4Xiieks6_ARAf7vuQNoSmzrGUNPtw"