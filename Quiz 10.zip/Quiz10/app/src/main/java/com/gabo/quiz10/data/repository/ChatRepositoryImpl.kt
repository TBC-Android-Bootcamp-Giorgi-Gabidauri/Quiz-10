package com.gabo.quiz10.data.repository

import com.gabo.quiz10.comon.handleResponse.HandleResponse
import com.gabo.quiz10.comon.handleResponse.Resource
import com.gabo.quiz10.comon.transformers.toModel
import com.gabo.quiz10.data.api.ChatApi
import com.gabo.quiz10.domain.model.ChatModel
import com.gabo.quiz10.domain.repository.ChatRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import javax.inject.Inject

class ChatRepositoryImpl @Inject constructor(
    private val api: ChatApi,
) : ChatRepository, HandleResponse {
    override suspend fun getChatInfo(): Flow<Resource<List<ChatModel>>> = flow {
        when (val result = handleResponse({ api.getChatInfo() }, "something went wrong")) {
            is Resource.Success -> emit(Resource.Success(result.data?.map { it.toModel() }))
            is Resource.Error -> emit(Resource.Error(result.errorMsg))
        }
    }
}