package com.gabo.quiz10.domain.useCases

import com.gabo.quiz10.base.BaseUseCase
import com.gabo.quiz10.comon.handleResponse.Resource
import com.gabo.quiz10.domain.model.ChatModel
import com.gabo.quiz10.domain.repository.ChatRepository
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class GetChatInfoUseCase @Inject constructor(private val chatRepository: ChatRepository) :
    BaseUseCase<Unit, Flow<Resource<List<ChatModel>>>> {
    override suspend fun invoke(params: Unit): Flow<Resource<List<ChatModel>>> {
        return chatRepository.getChatInfo()
    }
}